"""
נקודות קצה API לניהול קבוצות
"""
from typing import List
from fastapi import APIRouter, HTTPException, status

from models.models import GroupCreate, GroupUpdate, Group, ErrorResponse
from infisical.client import infisical_manager

# יצירת נתב עבור קבוצות
router = APIRouter()


@router.post("/", response_model=Group, status_code=status.HTTP_201_CREATED,
           responses={400: {"model": ErrorResponse}})
async def create_group(group_data: GroupCreate):
    """
    יצירת קבוצה (פרויקט) חדשה
    """
    try:
        result = await infisical_manager.create_project(
            name=group_data.name,
            description=group_data.description
        )
        return result
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"שגיאה ביצירת קבוצה: {str(e)}"
        )


@router.get("/", response_model=List[Group])
async def get_groups():
    """
    קבלת רשימת כל הקבוצות
    """
    try:
        return await infisical_manager.get_projects()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"שגיאה בקבלת רשימת קבוצות: {str(e)}"
        )


@router.get("/{group_id}", response_model=Group,
          responses={404: {"model": ErrorResponse}})
async def get_group(group_id: str):
    """
    קבלת פרטי קבוצה לפי מזהה
    """
    try:
        group = await infisical_manager.get_project(group_id)
        if not group:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"קבוצה עם מזהה {group_id} לא נמצאה"
            )
        return group
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"שגיאה בקבלת פרטי קבוצה: {str(e)}"
        )


@router.put("/{group_id}", response_model=Group,
          responses={404: {"model": ErrorResponse}, 400: {"model": ErrorResponse}})
async def update_group(group_id: str, group_data: GroupUpdate):
    """
    עדכון פרטי קבוצה
    """
    try:
        # בדיקה שהקבוצה קיימת
        existing_group = await infisical_manager.get_project(group_id)
        if not existing_group:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"קבוצה עם מזהה {group_id} לא נמצאה"
            )
        
        # עדכון הקבוצה
        updated_group = await infisical_manager.update_project(
            project_id=group_id,
            name=group_data.name,
            description=group_data.description
        )
        
        return updated_group
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"שגיאה בעדכון פרטי קבוצה: {str(e)}"
        )


@router.delete("/{group_id}", status_code=status.HTTP_204_NO_CONTENT,
             responses={404: {"model": ErrorResponse}})
async def delete_group(group_id: str):
    """
    מחיקת קבוצה
    """
    try:
        # בדיקה שהקבוצה קיימת
        existing_group = await infisical_manager.get_project(group_id)
        if not existing_group:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"קבוצה עם מזהה {group_id} לא נמצאה"
            )
        
        # מחיקת הקבוצה
        await infisical_manager.delete_project(group_id)
        
        return None
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"שגיאה במחיקת קבוצה: {str(e)}"
        )