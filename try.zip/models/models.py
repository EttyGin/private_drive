"""
מודלים לייצוג ותיקוף נתונים במערכת - רק עבור קבוצות
"""
from typing import Optional
from pydantic import BaseModel


class GroupBase(BaseModel):
    """מודל בסיס לקבוצה/פרויקט"""
    name: str
    description: Optional[str] = None


class GroupCreate(GroupBase):
    """מודל ליצירת קבוצה חדשה"""
    pass


class GroupUpdate(BaseModel):
    """מודל לעדכון קבוצה קיימת"""
    name: Optional[str] = None
    description: Optional[str] = None


class Group(GroupBase):
    """מודל מלא לקבוצה"""
    id: str
    
    class Config:
        orm_mode = True


class ErrorResponse(BaseModel):
    """מודל לשגיאה"""
    detail: str