from fastapi import APIRouter

from endpoints import groups

api_router = APIRouter()

# הוספת נתבים מהמודולים השונים
api_router.include_router(groups.router, prefix="/groups", tags=["groups"])