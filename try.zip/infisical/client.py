"""
מודול לעבודה מול Infisical API
"""
from typing import Dict, Any, Optional, List
import httpx

from infisical_sdk import InfisicalSDKClient
import requests

INFISICAL_TOKEN="st.d15d9e90-d1d1-49e2-a178-15e9f286f755.442f33ad0a2d4ac25b537928363109eb.0c833a3950d9bb5116b7f12b35ea39b7"
INFISICAL_API_URL="http://localhost/api"


class InfisicalManager:
    """
    מחלקה לניהול תקשורת עם Infisical API
    """
    
    def __init__(self):
        """אתחול מנהל Infisical"""
        self.client = InfisicalSDKClient(host=INFISICAL_API_URL, token=INFISICAL_TOKEN)
    
    # ========== ניהול פרויקטים/קבוצות ==========
    
    async def create_project(self, name: str, description: Optional[str] = None) -> Dict[str, Any]:
        """
        יצירת פרויקט חדש ב-Infisical
        
        :param name: שם הפרויקט
        :param description: תיאור הפרויקט (אופציונלי)
        :return: פרטי הפרויקט שנוצר
        """
        project_data = {
            "name": name,
        }
        if description:
            project_data["description"] = description
            
        return await self.client.create_project(project_data)
    
    async def get_project(self, project_id: str) -> Dict[str, Any]:
        """
        קבלת פרטי פרויקט לפי מזהה
        
        :param project_id: מזהה הפרויקט
        :return: פרטי הפרויקט
        """
        return await self.client.get_project(project_id)
    
    async def get_projects(self) -> List[Dict[str, Any]]:
    # def get_all_projects(site_url: str, token: str):
        organization_id="bd5d7bf1-441c-41fd-86f8-c76e35b37cc3"

        url = f"{self.client.host}/v2/organizations/{organization_id}/workspaces"
        headers = {
            "Authorization": f"Bearer {INFISICAL_TOKEN}"
        }
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            return response.json().get("workspaces", [])
        else:
            print(f"Error {response.status_code}: {response.text}")
            return []        
    async def update_project(self, project_id: str, name: Optional[str] = None, 
                            description: Optional[str] = None) -> Dict[str, Any]:
        """
        עדכון פרטי פרויקט
        
        :param project_id: מזהה הפרויקט
        :param name: שם חדש (אופציונלי)
        :param description: תיאור חדש (אופציונלי)
        :return: פרטי הפרויקט המעודכן
        """
        update_data = {}
        if name:
            update_data["name"] = name
        if description:
            update_data["description"] = description
            
        return await self.client.update_project(project_id, update_data)
    
    async def delete_project(self, project_id: str) -> Dict[str, Any]:
        """
        מחיקת פרויקט
        
        :param project_id: מזהה הפרויקט
        :return: אישור המחיקה
        """
        return await self.client.delete_project(project_id)
    
    # ========== ניהול משתמשים בפרויקט ==========
    
    async def add_user_to_project(self, project_id: str, email: str, role: str = "member") -> Dict[str, Any]:
        """
        הוספת משתמש לפרויקט
        
        :param project_id: מזהה הפרויקט
        :param email: אימייל המשתמש
        :param role: תפקיד המשתמש (ברירת מחדל: member)
        :return: אישור ההוספה
        """
        return await self.client.add_project_member(project_id, email, role)
    
    async def get_project_users(self, project_id: str) -> List[Dict[str, Any]]:
        """
        קבלת רשימת משתמשים בפרויקט
        
        :param project_id: מזהה הפרויקט
        :return: רשימת משתמשים
        """
        return await self.client.get_project_members(project_id)
    
    async def remove_user_from_project(self, project_id: str, user_id: str) -> Dict[str, Any]:
        """
        הסרת משתמש מפרויקט
        
        :param project_id: מזהה הפרויקט
        :param user_id: מזהה המשתמש
        :return: אישור ההסרה
        """
        return await self.client.remove_project_member(project_id, user_id)
    
    # ========== ניהול סודות ==========
    
    async def create_secret(self, project_id: str, environment: str, 
                          key: str, value: str, type: str = "shared") -> Dict[str, Any]:
        """
        יצירת סוד חדש
        
        :param project_id: מזהה הפרויקט
        :param environment: סביבת העבודה (למשל "dev", "prod")
        :param key: מפתח הסוד
        :param value: ערך הסוד
        :param type: סוג הסוד (ברירת מחדל: shared)
        :return: פרטי הסוד שנוצר
        """
        secret_data = {
            "key": key,
            "value": value,
            "type": type
        }
        return await self.client.create_secret(project_id, environment, secret_data)
    
    async def get_secret(self, project_id: str, environment: str, 
                       secret_id: str) -> Dict[str, Any]:
        """
        קבלת פרטי סוד ספציפי
        
        :param project_id: מזהה הפרויקט
        :param environment: סביבת העבודה
        :param secret_id: מזהה הסוד
        :return: פרטי הסוד
        """
        return await self.client.get_secret(project_id, environment, secret_id)
    
    async def get_secrets(self, project_id: str, environment: str) -> List[Dict[str, Any]]:
        """
        קבלת כל הסודות בפרויקט ובסביבה מסוימת
        
        :param project_id: מזהה הפרויקט
        :param environment: סביבת העבודה
        :return: רשימת סודות
        """
        return await self.client.get_secrets(project_id, environment)
    
    async def update_secret(self, project_id: str, environment: str, 
                          secret_id: str, value: str) -> Dict[str, Any]:
        """
        עדכון ערך סוד
        
        :param project_id: מזהה הפרויקט
        :param environment: סביבת העבודה
        :param secret_id: מזהה הסוד
        :param value: ערך חדש
        :return: פרטי הסוד המעודכן
        """
        update_data = {"value": value}
        return await self.client.update_secret(project_id, environment, secret_id, update_data)
    
    async def delete_secret(self, project_id: str, environment: str, 
                          secret_id: str) -> Dict[str, Any]:
        """
        מחיקת סוד
        
        :param project_id: מזהה הפרויקט
        :param environment: סביבת העבודה
        :param secret_id: מזהה הסוד
        :return: אישור המחיקה
        """
        return await self.client.delete_secret(project_id, environment, secret_id)


# יצירת אובייקט מנהל גלובלי
infisical_manager = InfisicalManager()