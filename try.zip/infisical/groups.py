"""
מודול ספציפי לניהול קבוצות מול Infisical
המיישם לוגיקה מורכבת יותר מעבר לפעולות הבסיסיות של הלקוח
"""
from typing import Dict, Any, Optional, List
from infisical.client import infisical_manager


async def create_group_with_validation(name: str, description: Optional[str] = None) -> Dict[str, Any]:
    """
    יצירת קבוצה חדשה עם תיקוף נוסף
    
    :param name: שם הקבוצה
    :param description: תיאור הקבוצה (אופציונלי)
    :return: פרטי הקבוצה שנוצרה
    """
    # בדיקה שאין קבוצה קיימת עם אותו שם
    existing_groups = await infisical_manager.get_projects()
    for group in existing_groups:
        if group.get("name") == name:
            raise ValueError(f"קבוצה בשם '{name}' כבר קיימת במערכת")
    
    # יצירת הקבוצה
    return await infisical_manager.create_project(name, description)


async def get_group_details(group_id: str) -> Dict[str, Any]:
    """
    קבלת פרטים מורחבים על קבוצה
    
    :param group_id: מזהה הקבוצה
    :return: פרטי הקבוצה כולל נתונים נוספים
    """
    # קבלת פרטי הקבוצה הבסיסיים
    group = await infisical_manager.get_project(group_id)
    
    if not group:
        return None
    
    # הוספת מידע על כמות המשתמשים בקבוצה
    users = await infisical_manager.get_project_users(group_id)
    group["user_count"] = len(users)
    
    return group


async def get_all_groups_with_details() -> List[Dict[str, Any]]:
    """
    קבלת כל הקבוצות עם פרטים נוספים
    
    :return: רשימת קבוצות עם פרטים נוספים
    """
    groups = await infisical_manager.get_projects()
    
    # הוספת פרטים נוספים לכל קבוצה
    result = []
    for group in groups:
        group_id = group.get("id")
        detailed_group = await get_group_details(group_id)
        result.append(detailed_group)
    
    return result