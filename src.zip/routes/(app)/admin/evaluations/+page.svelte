<script>
	import Evaluations from '$lib/components/admin/Evaluations.svelte';
</script>

<Evaluations />
