<script>
	import Chat from '$lib/components/playground/Chat.svelte';
</script>

<Chat />
