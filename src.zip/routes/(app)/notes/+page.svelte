<script>
	import Notes from '$lib/components/notes/Notes.svelte';
</script>

<Notes />
