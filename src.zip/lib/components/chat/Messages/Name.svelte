<div class=" self-center font-semibold line-clamp-1 flex gap-1 items-center">
	<slot />
</div>
